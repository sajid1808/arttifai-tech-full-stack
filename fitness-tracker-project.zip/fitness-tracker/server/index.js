
const express = require("express");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const pg = require("pg");
const bcrypt = require("bcrypt");

const app = express();
app.use(cors());
app.use(express.json());

const pool = new pg.Pool({
  user: "postgres",
  host: "localhost",
  database: "fitness_tracker",
  password: "your_password",
  port: 5432,
});

const SECRET = "your_jwt_secret";

app.post("/register", async (req, res) => {
  const { username, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  await pool.query("INSERT INTO users (username, password) VALUES ($1, $2)", [username, hashed]);
  res.json({ message: "Registered" });
});

app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const user = await pool.query("SELECT * FROM users WHERE username = $1", [username]);
  if (user.rows.length === 0 || !(await bcrypt.compare(password, user.rows[0].password))) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = jwt.sign({ id: user.rows[0].id }, SECRET);
  res.json({ token });
});

app.post("/workouts", async (req, res) => {
  const token = req.headers.authorization;
  const { type, duration, calories } = req.body;
  const decoded = jwt.verify(token, SECRET);
  await pool.query("INSERT INTO workouts (user_id, type, duration, calories) VALUES ($1, $2, $3, $4)", [decoded.id, type, duration, calories]);
  res.json({ message: "Workout saved" });
});

app.listen(5000, () => console.log("Server running on port 5000"));
