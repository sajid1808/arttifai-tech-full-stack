
import React, { useState } from "react";
import axios from "axios";

const API = "http://localhost:5000";

function App() {
  const [token, setToken] = useState("");
  const [data, setData] = useState({ username: "", password: "" });
  const [workout, setWorkout] = useState({ type: "", duration: "", calories: "" });

  const register = async () => {
    await axios.post(`${API}/register`, data);
    alert("Registered!");
  };

  const login = async () => {
    const res = await axios.post(`${API}/login`, data);
    setToken(res.data.token);
  };

  const addWorkout = async () => {
    await axios.post(`${API}/workouts`, workout, {
      headers: { Authorization: token }
    });
    alert("Workout added");
  };

  return (
    <div>
      <h2>Fitness Tracker</h2>

      <input placeholder="Username" onChange={e => setData({ ...data, username: e.target.value })} />
      <input type="password" placeholder="Password" onChange={e => setData({ ...data, password: e.target.value })} />
      <button onClick={register}>Register</button>
      <button onClick={login}>Login</button>

      <br /><br />
      {token && (
        <>
          <input placeholder="Type" onChange={e => setWorkout({ ...workout, type: e.target.value })} />
          <input placeholder="Duration" onChange={e => setWorkout({ ...workout, duration: e.target.value })} />
          <input placeholder="Calories" onChange={e => setWorkout({ ...workout, calories: e.target.value })} />
          <button onClick={addWorkout}>Add Workout</button>
        </>
      )}
    </div>
  );
}

export default App;
